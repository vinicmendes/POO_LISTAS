
package atividade04.modelo;

/**
 *
 * @author vinicius
 */
public interface arrayInterface {
    public int tamanho();
    
    public Object getVet();
    
    @Override
    public String toString();
}
